# shared-vuejs

Browser ES module library for the Desq editor. It is built independently and is not an npm workspace. The editor installs the compiled tarball declared in its `package.json`; it does not import this project's source directory.

## Build and consume

From the repository root:

```sh
npm run build:shared   # compiled ES modules, declarations, CSS, WASM, and workers
npm run update:shared  # build, pack into packages/, and refresh the editor dependency
npm --prefix editor-vuejs run build
```

Commit the updated tarball and package-lock.json together when changing the library. The tarball path is pinned in editor-vuejs/package.json. Increase the package version and update that path when releasing a new version.

To work with this library in its own checkout, run `npm install`, `npm run build`, and `npm pack`. Install the resulting tarball in the consumer, or publish it to a private registry after choosing the release version and registry settings.

## Development and debugging

```sh
npm run dev                         # from the repository root
npm --prefix editor-vuejs run editor:dev
npm --prefix editor-vuejs run editor:dev:package  # debug the installed tarball
```

The first two commands start Vite with the local library watcher. It compiles source changes into `shared-vuejs/dist`, then automatically reloads the browser after a successful build. Vite resolves only the library's declared public exports to this compiled output; production builds continue to use the installed tarball. Editor Vue components retain their normal HMR.

Library store modules attach DOM listeners and keep singleton state, so library edits trigger a full browser reload. Failed library builds keep the last working output and show an error overlay; fixing the error reloads the browser. Watch mode skips declaration generation for quicker updates.

Every compiled JavaScript module has a linked `.map` file with the original source embedded. Enable JavaScript source maps in browser DevTools to set breakpoints and step through the original `.ts` and `.tsx` files. Import rewriting is included in these mappings. The maps also ship in the tarball, so the original checkout is not required for debugging an installed version.

For a library in another checkout, set `SHARED_VUEJS_DIR=/absolute/path/to/shared-vuejs` when starting editor development. Vue and VanJS still resolve to the editor's peer runtimes. To watch only the library, run `npm run watch:shared` at the repository root or `npm run dev` inside the library.

Changes in watch mode do not update the release tarball. Run `npm run update:shared` when ready to refresh the packaged dependency.

## Public interface

```js
import { updateShape, getEditorState } from 'shared-vuejs/editor';
import { on, off } from 'shared-vuejs/events';
import globals from 'shared-vuejs/global';
import 'shared-vuejs/api/DragDropTouch';
import 'shared-vuejs/api/main.css';
```

The flat `api` exports and JSX runtimes are listed in package.json. Source paths are private. Internal source aliases are rewritten to relative compiled imports during the build. Vue and VanJS packages are peers so the consumer shares one runtime instance.

The output targets browser bundlers such as Vite. CSS imports, assets, workers, and `import.meta.env` remain available for the consumer bundler to process. Browser entry points expect DOM and browser storage APIs.

The source interface tests run with `npm run test:interface` after building. The `store` and `selShp` events carry detached UI data; active document queries still return live document models. Commit edits with the document/shape update functions so saving and dirty tracking run.
